package generic;

import java.io.DataInputStream;
import java.io.FileInputStream;
// import java.io.FileNotFoundException;
import java.io.IOException;
// import java.io.InputStream;
import java.util.Arrays;

import processor.Clock;
import processor.Processor;

public class Simulator {
		
	static Processor processor;
	static boolean simulationComplete;
	
	public static void setupSimulation(String assemblyProgramFile, Processor p)
	{
		Simulator.processor = p;
		loadProgram(assemblyProgramFile);
		
		simulationComplete = false;
	}
	
	static void loadProgram(String assemblyProgramFile)
	{
		try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(assemblyProgramFile))) {
			int PC = dataInputStream.readInt();
			processor.getRegisterFile().setProgramCounter(PC);
			int address = 0;
            while (dataInputStream.available() >= 4) {
				int instruction = dataInputStream.readInt();
				processor.getMainMemory().setWord(address, instruction);
				address++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

		processor.getRegisterFile().setValue(1, 65535);
		processor.getRegisterFile().setValue(2, 65535);
		// processor.printState(0, 20);
	}
	
	public static void simulate()
	{
		while(simulationComplete == false)
		{
			System.out.println("-----------------------------");
			System.out.println(Arrays.toString(processor.getILUnit().printArray()));
			processor.getRWUnit().performRW();
			processor.getMAUnit().performMA();
			processor.getEXUnit().performEX();
			processor.getOFUnit().performOF();
			processor.getIFUnit().performIF();
			Clock.incrementClock();

			// if (Clock.getCurrentTime() >= 1200) setSimulationComplete(true);
			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions() + 1);
			Statistics.setNumberOfCycles(Statistics.getNumberOfCycles() + 1);
		}

		if (simulationComplete == true)
		{
			Statistics.numberOfStalls = processor.getILUnit().getNoDataHazard();
			Statistics.numberOfBranch = processor.getILUnit().getNoControlHazard();
		}
		
		// TODO
		// set statistics
	}
	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}
}
