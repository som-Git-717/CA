package processor.pipeline;

public class Interlock_Unit {

    int data_InterlockArray[] = new int[32];
    int buffer_RegisterNumber;
    int endEnable;
    boolean isBranch;
    boolean branchingTriggered;
    int number_DataHarzard;
    int number_ControlHarzard;

    public Interlock_Unit()
    {
        for (int i = 0; i < 32; i++){
            data_InterlockArray[i] = 0;
        }

        buffer_RegisterNumber = -1;
        endEnable = 0;
        isBranch = false;
        branchingTriggered = false;
        number_ControlHarzard = 0;
        number_DataHarzard = 0;
    }

    public void set_dataInterlock(int registerNumber, int value){
        data_InterlockArray[registerNumber] = value;
    }

    public int get_dataInterlock(int registerNumber){
        return data_InterlockArray[registerNumber];
    }

    public boolean isdataInterlock(int registerNumber){
        return (data_InterlockArray[registerNumber] == 1 || data_InterlockArray[registerNumber] == 2) ? true : false;
    }

    public int[] printArray(){
        return data_InterlockArray;
    }

    public void setbufferRN(int registerNumber){
        buffer_RegisterNumber = registerNumber;
    }

    public int getbufferRN(){
        return buffer_RegisterNumber;
    }

    public void setIsBranch(boolean value){
        isBranch = value;
    }

    public boolean getIsBranch(){
        return isBranch;
    }

    public void setBT(boolean value){
        branchingTriggered = value;
    }

    public boolean getBT(){
        return branchingTriggered;
    }

    public int getNoDataHazard(){
        return number_DataHarzard;
    }

    public int getNoControlHazard(){
        return number_ControlHarzard;
    }

}
