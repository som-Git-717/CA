package processor.pipeline;

import processor.Processor;
import generic.Instruction;

public class MemoryAccess {
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
	}
	
	public void performMA()
	{
		System.out.print("Reach MA ");
		if (EX_MA_Latch.isMA_enable() == true)
		{

			//Branching
			if (containingProcessor.getILUnit().getIsBranch())
			{
				containingProcessor.getILUnit().number_ControlHarzard += 1;
				containingProcessor.getILUnit().setBT(true);
				EX_MA_Latch.getEX_IF().setIFE_enable(true);
				EX_MA_Latch.getEX_IF().setbranchPC(EX_MA_Latch.getAluResult());
			}
			
			// Extracting Instruction and Control Signals
			Instruction instruction = EX_MA_Latch.getInstruction();
			Control_Signals controlSignals = EX_MA_Latch.geControlSignals();

			System.out.println("MA " + instruction.getProgramCounter());

			int aluResult = EX_MA_Latch.getAluResult();

			if (controlSignals.isStr == true)
			{
				int value_store = instruction.getDestinationOperand().getValue();
				containingProcessor.getMainMemory().setWord(aluResult, value_store);
			}
			
			if (controlSignals.isLd == true)
			{
				int load_result = containingProcessor.getMainMemory().getWord(aluResult);
				MA_RW_Latch.setLoadResult(load_result);
			}


			MA_RW_Latch.setInstruction(instruction);
			MA_RW_Latch.setAluResult(aluResult);
			MA_RW_Latch.setControlSignals(controlSignals);
			MA_RW_Latch.setRW_enable(true);
			EX_MA_Latch.setMA_enable(false);
		}
	}

}
