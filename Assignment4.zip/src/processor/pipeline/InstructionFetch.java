package processor.pipeline;

import processor.Processor;

public class InstructionFetch {
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{
		System.out.print("Reach IF ");
		if(IF_EnableLatch.isIF_enable() && IF_OF_Latch.get_stallEnable() == false)
		{
			int currentPC = 0;
			if (EX_IF_Latch.isIFE_enable())
			{
				currentPC = EX_IF_Latch.getbranchPC();
			}
			else
			{
				currentPC = containingProcessor.getRegisterFile().getProgramCounter();
				
			}
			System.out.println("IF " + currentPC);
			int newInstruction = containingProcessor.getMainMemory().getWord(currentPC);
			IF_OF_Latch.setInstruction(newInstruction);
			IF_OF_Latch.set_PerformingPC(currentPC);
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);
			
			EX_IF_Latch.setIFE_enable(false);
			// IF_EnableLatch.setIF_enable(false);
			IF_OF_Latch.setOF_enable(true);
		}
		else if (IF_OF_Latch.get_stallEnable())
		{
			containingProcessor.getILUnit().number_DataHarzard += 1;
			IF_OF_Latch.setOF_enable(true);
			IF_OF_Latch.set_stallEnable(false);
		}	
	}

}
