package processor.pipeline;

import generic.Instruction;

public class EX_MA_LatchType {
	
	boolean MA_enable;
	int aluResult;
	Instruction instruction;
	Control_Signals controlSignals;
	EX_IF_LatchType EX_IF_Latch;
	
	public EX_MA_LatchType()
	{
		MA_enable = false;
	}

	public boolean isMA_enable() {
		return MA_enable;
	}

	public void setMA_enable(boolean mA_enable) {
		MA_enable = mA_enable;
	}

	public int getAluResult()
	{
		return aluResult;
	}

	public void setAluResult(int result)
	{
		this.aluResult = result;
	}

	public Instruction getInstruction()
	{
		return instruction;
	}

	public void setInstruction(Instruction instruction)
	{
		this.instruction = instruction;
	}

	public Control_Signals geControlSignals()
	{
		return controlSignals;
	}

	public void setControlSignals(Control_Signals controlSignals)
	{
		this.controlSignals = controlSignals;
	}

	public void setEX_IF(EX_IF_LatchType EX_IF_Latch){
		this.EX_IF_Latch = EX_IF_Latch;
	}

	public EX_IF_LatchType getEX_IF(){
		return EX_IF_Latch;
	}
	

}
