package processor.pipeline;

import processor.Processor;
import generic.Instruction;
import generic.Operand;

public class Execute {
	Processor containingProcessor;
	OF_EX_LatchType OF_EX_Latch;
	EX_MA_LatchType EX_MA_Latch;
	EX_IF_LatchType EX_IF_Latch;
	
	public Execute(Processor containingProcessor, OF_EX_LatchType oF_EX_Latch, EX_MA_LatchType eX_MA_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.OF_EX_Latch = oF_EX_Latch;
		this.EX_MA_Latch = eX_MA_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performEX()
	{
		System.out.print("Reach EX ");
		if (OF_EX_Latch.isEX_enable() && containingProcessor.getILUnit().getBT() == false)
		{
			// Extracting Instruction and Control Signals
			Instruction instruction = OF_EX_Latch.getInstruction();
			Control_Signals controlSignals = OF_EX_Latch.geControlSignals();

			System.out.println("EX " + instruction.getProgramCounter());

			// Operand Values
			int A = instruction.getSourceOperand1().getValue();
			int B = instruction.getSourceOperand2().getValue();

			int aluSignal = controlSignals.getAluSignal();
			int currentPC = instruction.getProgramCounter();

			int aluResult = 0;
			switch (aluSignal) {
				case 1:
					aluResult = A + B;
					break;
				case 2:
					aluResult = A - B;
					break;
				case 3:
					aluResult = A * B;
					break;
				case 4:
					aluResult = A / B;
					containingProcessor.getRegisterFile().setValue(31, A % B);
					break;
				case 5:
					aluResult = A & B;
					break;
				case 6:
					aluResult = A | B;
					break;
				case 7:
					aluResult = A ^ B;
					break;
				case 8:
					aluResult = (A < B) ? 1 : 0;
					break;
				case 9:
					aluResult = A << B;
					break;
				case 10:
					aluResult = A >>> B;
					break;
				case 11:
					aluResult = A >> B;
					break;
				case 12:
					if (A == instruction.getDestinationOperand().getValue()) 
					{
						aluResult = B + currentPC;
						containingProcessor.getILUnit().setIsBranch(true);
					}
					break;
				case 13:
					if (A != instruction.getDestinationOperand().getValue())
					{
						aluResult = B + currentPC;
						containingProcessor.getILUnit().setIsBranch(true);
					}
					break;
				case 14:
					if (A < instruction.getDestinationOperand().getValue())
					{
						aluResult = B + currentPC;
						containingProcessor.getILUnit().setIsBranch(true);
					}
					break;
				case 15:
					if (A > instruction.getDestinationOperand().getValue())
					{
						aluResult = B + currentPC;
						containingProcessor.getILUnit().setIsBranch(true);
					}
					break;
			
				default:
					break;
			}

			if (controlSignals.isJmp == true)
			{
				aluResult = B + currentPC;
				containingProcessor.getILUnit().setIsBranch(true);
			}

			if (controlSignals.isStr == true || controlSignals.isLd == true)
			{
				aluResult = A + B;
			}

			OF_EX_Latch.setEX_enable(false);
			EX_MA_Latch.setMA_enable(true);
			EX_MA_Latch.setInstruction(instruction);
			EX_MA_Latch.setControlSignals(controlSignals);
			EX_MA_Latch.setAluResult(aluResult);
			EX_MA_Latch.setEX_IF(EX_IF_Latch);
		}
		else if (containingProcessor.getILUnit().getBT())
		{
			System.out.println("EX -1");

			Operand null_Operand = new Operand();
			null_Operand.setValue(0);

			Control_Signals controlSignals = new Control_Signals();
			controlSignals.getControlSignals(-1);

			Instruction instruction = new Instruction();
			instruction.setProgramCounter(-1);
			instruction.setSourceOperand1(null_Operand);
			instruction.setSourceOperand2(null_Operand);
			instruction.setDestinationOperand(null_Operand);

			OF_EX_Latch.setEX_enable(false);
			EX_MA_Latch.setMA_enable(true);
			EX_MA_Latch.setInstruction(instruction);
			EX_MA_Latch.setControlSignals(controlSignals);
			EX_MA_Latch.setAluResult(0);

		}
	}

}
