package processor.pipeline;

import processor.Processor;
import generic.Instruction;
import generic.Instruction.OperationType;
import generic.Operand;
import generic.Operand.OperandType;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	Control_Signals controlSignals;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
	}
	
	private static StringBuilder twosCompliment(StringBuilder input){
		int index=0;
		for (int i = 0; i < input.length(); i++)
		{
			if(input.charAt(i) == '1') index = i;
		}
		StringBuilder output = input;
		for(int i = 0; i < index; i++)
		{
			if (output.charAt(i) == '0') output.setCharAt(i, '1');
			else output.setCharAt(i, '0');
		}
		return output;
	}

	public void performOF()
	{
		if(IF_OF_Latch.isOF_enable())
		{
			// System.out.println("Operand");
			//Control Unit
			controlSignals = new Control_Signals();

			//Fetching Instruction
			int newInstruction = IF_OF_Latch.getInstruction();
			String binaryInstruction = Integer.toBinaryString(newInstruction);
			while(binaryInstruction.length()!=32)
			{
				binaryInstruction = "0" + binaryInstruction;
			}
			// System.out.println(binaryInstruction);

			//Opcode from Instruction
			String opcode = binaryInstruction.substring(0, 5);
			int intOpcode = Integer.parseInt(opcode, 2);
			controlSignals.getControlSignals(intOpcode);
			
			Instruction instruction = new Instruction();

			if (intOpcode % 2 == 0 && intOpcode < 21){
				Operand rs1 = new Operand();
				int value1 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(5, 10), 2));
				rs1.setOperandType(OperandType.Register);
				rs1.setValue(value1);

				Operand rs2 = new Operand();
				int value2 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(10, 15), 2));
				rs2.setOperandType(OperandType.Register);
				rs2.setValue(value2);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				rd.setValue(Integer.parseInt(binaryInstruction.substring(15, 20), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(rs1);
				instruction.setSourceOperand2(rs2);
				instruction.setDestinationOperand(rd);

			}
			else if (intOpcode % 2 != 0 && intOpcode <= 21 || intOpcode == 22){
				Operand rs1 = new Operand();
				int value1 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(5, 10), 2));
				rs1.setOperandType(OperandType.Register);
				rs1.setValue(value1);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				rd.setValue(Integer.parseInt(binaryInstruction.substring(10, 15), 2));

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1')
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(rs1);
				instruction.setSourceOperand2(immediate);
				instruction.setDestinationOperand(rd);
			}
			else if (intOpcode == 23)
			{
				Operand rs1 = new Operand();
				rs1.setOperandType(OperandType.Register);
				rs1.setValue(Integer.parseInt(binaryInstruction.substring(5, 10), 2));

				Operand rd = new Operand();
				int value2 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(10, 15), 2));
				rd.setOperandType(OperandType.Register);
				rd.setValue(value2);

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1')
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(rd);
				instruction.setSourceOperand2(immediate);
				instruction.setDestinationOperand(rs1);
			}
			else if (intOpcode == 24)
			{
				Operand immediate = new Operand();
				Operand null_operand = new Operand();
				null_operand.setValue(0);
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(10, 32));
				if (immBinary.charAt(0) == '1')
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(null_operand);
				instruction.setSourceOperand2(immediate);

			}
			else if (intOpcode == 29){
				Operand null_operand = new Operand();
				null_operand.setValue(0);
				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(null_operand);
				instruction.setSourceOperand2(null_operand);
				instruction.setDestinationOperand(null_operand);
			}
			else{
				Operand rs1 = new Operand();
				int value_1 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(5, 10), 2));
				rs1.setOperandType(OperandType.Register);
				rs1.setValue(value_1);

				Operand rd = new Operand();
				int value_2 = containingProcessor.getRegisterFile().getValue(Integer.parseInt(binaryInstruction.substring(10, 15), 2));
				rd.setOperandType(OperandType.Register);
				rd.setValue(value_2);

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1')
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(rs1);
				instruction.setSourceOperand2(immediate);
				instruction.setDestinationOperand(rd);
			}
			
			OF_EX_Latch.setControlSignals(controlSignals);
			OF_EX_Latch.setInstruction(instruction);
			IF_OF_Latch.setOF_enable(false);
			OF_EX_Latch.setEX_enable(true);
		}
	}

}
