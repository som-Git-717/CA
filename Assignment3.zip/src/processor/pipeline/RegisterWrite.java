package processor.pipeline;

import generic.Instruction;
import processor.Processor;
import generic.Simulator;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		if(MA_RW_Latch.isRW_enable())
		{
			// System.out.println("RegisterWrite");

			Instruction instruction = MA_RW_Latch.getInstruction();
			Control_Signals controlSignals = MA_RW_Latch.geControlSignals();
			int aluResult = MA_RW_Latch.getAluResult();
			int loadResult = MA_RW_Latch.getLoadResult();
			if (controlSignals.isLd == true)
			{
				int rd = instruction.getDestinationOperand().getValue();
				containingProcessor.getRegisterFile().setValue(rd, loadResult);
			}
			else if (instruction.getOperationType().ordinal() == 29)
			{
				Simulator.setSimulationComplete(true);
			}

			else if ((controlSignals.isJmp || controlSignals.isStr || (12<=controlSignals.getAluSignal() && controlSignals.getAluSignal()<=15)) == false)
			{
				int rd = instruction.getDestinationOperand().getValue();
				containingProcessor.getRegisterFile().setValue(rd, aluResult);
			}
			

			MA_RW_Latch.setRW_enable(false);
			IF_EnableLatch.setIF_enable(true);
		}
	}

}
