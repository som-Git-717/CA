package processor.pipeline;

public class EX_IF_LatchType {

	boolean IFE_enable;
	int branchPC;
	public EX_IF_LatchType()
	{
		IFE_enable = false;
	}

	public boolean isIFE_enable() {
		return IFE_enable;
	}

	public void setIFE_enable(boolean eX_enable) {
		IFE_enable = eX_enable;
	}

	public int getbranchPC (){
		return branchPC;
	}

	public void setbranchPC (int newPC)
	{
		branchPC = newPC;
	}

}
