package processor.pipeline;

import generic.Instruction;
import processor.Processor;
import generic.Simulator;

public class RegisterWrite {
	Processor containingProcessor;
	MA_RW_LatchType MA_RW_Latch;
	IF_EnableLatchType IF_EnableLatch;
	
	public RegisterWrite(Processor containingProcessor, MA_RW_LatchType mA_RW_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.MA_RW_Latch = mA_RW_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	public void performRW()
	{
		System.out.println("Reach RW");
		if (containingProcessor.getILUnit().getbufferRN() != -1)
		{
			containingProcessor.getILUnit().set_dataInterlock(containingProcessor.getILUnit().getbufferRN(), 0);
			containingProcessor.getILUnit().setbufferRN(-1);
		}

		if(MA_RW_Latch.isRW_enable() && MA_RW_Latch.isMABusy() == false)
		{
			// Extracting Instruction and Control Signals
			Instruction instruction = MA_RW_Latch.getInstruction();
			Control_Signals controlSignals = MA_RW_Latch.geControlSignals();

			System.out.println(" RW " + instruction.getProgramCounter());
			
			int aluResult = MA_RW_Latch.getAluResult();
			int loadResult = MA_RW_Latch.getLoadResult();

			if (controlSignals.isLd == true)
			{
				int rd_RegisterNumber = instruction.getDestinationOperand().getRegisterNumber();
				containingProcessor.getRegisterFile().setValue(rd_RegisterNumber, loadResult);

				if (containingProcessor.getILUnit().get_dataInterlock(rd_RegisterNumber) == 2){
					containingProcessor.getILUnit().set_dataInterlock(rd_RegisterNumber, 1);
					containingProcessor.getILUnit().setbufferRN(rd_RegisterNumber);
				}
			}
			else if (instruction.getOperationType() != null && instruction.getOperationType().ordinal() == 29)
			{
				Simulator.setSimulationComplete(true);
			}

			else if ((controlSignals.isJmp || controlSignals.isStr || (12<=controlSignals.getAluSignal() && controlSignals.getAluSignal()<=15)) == false)
			{
				int rd_RegisterNumber = instruction.getDestinationOperand().getRegisterNumber();
				containingProcessor.getRegisterFile().setValue(rd_RegisterNumber, aluResult);

				if (containingProcessor.getILUnit().get_dataInterlock(rd_RegisterNumber) == 2){
					containingProcessor.getILUnit().set_dataInterlock(rd_RegisterNumber, 1);
					containingProcessor.getILUnit().setbufferRN(rd_RegisterNumber);
				}
			}
			

			MA_RW_Latch.setRW_enable(false);
			IF_EnableLatch.setIF_enable((containingProcessor.getILUnit().endEnable == 1) ? false : true);
		}
	}

}
