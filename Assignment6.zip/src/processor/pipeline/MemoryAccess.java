package processor.pipeline;

import processor.Processor;
import generic.*;
import generic.Event.EventType;
import processor.Clock;
import configuration.Configuration;

public class MemoryAccess implements Element{
	Processor containingProcessor;
	EX_MA_LatchType EX_MA_Latch;
	MA_RW_LatchType MA_RW_Latch;
	EX_IF_LatchType EX_IF_Latch;

	int aluResult;
	Instruction instruction;
	Control_Signals controlSignals;
	int load_result;
	
	public MemoryAccess(Processor containingProcessor, EX_MA_LatchType eX_MA_Latch, MA_RW_LatchType mA_RW_Latch, EX_IF_LatchType ex_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.EX_MA_Latch = eX_MA_Latch;
		this.MA_RW_Latch = mA_RW_Latch;
		this.EX_IF_Latch = ex_IF_Latch;
	}
	
	public void performMA()
	{
		System.out.println("Reach MA");
		if (containingProcessor.getLTUnit().is_MABusy() == false && containingProcessor.getLTUnit().is_EXBusy() == false)
		{
			if (EX_MA_Latch.isMA_enable() && EX_MA_Latch.isEXBusy() == false && MA_RW_Latch.isMABusy() == false)
			{
				//Branching
				if (containingProcessor.getILUnit().getIsBranch())
				{
					containingProcessor.getILUnit().number_ControlHarzard += 1;
					containingProcessor.getILUnit().setBT(true);

					EX_IF_Latch.setIFE_enable(true);
					EX_IF_Latch.setbranchPC(EX_MA_Latch.getAluResult());
				}
				
				// Extracting Instruction and Control Signals
				instruction = EX_MA_Latch.getInstruction();
				controlSignals = EX_MA_Latch.geControlSignals();

				System.out.println(instruction.getProgramCounter());

				aluResult = EX_MA_Latch.getAluResult();

				if (controlSignals.isStr == true)
				{
					int value_store = instruction.getDestinationOperand().getValue();
					Simulator.getEventQueue().addEvent(
						new MemoryWriteEvent(Clock.getCurrentTime() + containingProcessor.getL1dCache().getcacheLatency(), this, containingProcessor.getL1dCache(), aluResult, value_store));

					// Simulator.getEventQueue().addEvent(
					// 	new MemoryWriteEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency, this, containingProcessor.getMainMemory(), aluResult, value_store));

					containingProcessor.getLTUnit().set_MABusy(true);
				}
				else if (controlSignals.isLd == true)
				{	

					Simulator.getEventQueue().addEvent(
						new MemoryReadEvent(Clock.getCurrentTime() + containingProcessor.getL1dCache().getcacheLatency(), this, containingProcessor.getL1dCache(), aluResult));

					// Simulator.getEventQueue().addEvent(
					// 	new MemoryReadEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency, this, containingProcessor.getMainMemory(), aluResult));

					containingProcessor.getLTUnit().set_MABusy(true);
				}
				else
				{
					MA_RW_Latch.setInstruction(instruction);
					MA_RW_Latch.setAluResult(aluResult);
					MA_RW_Latch.setControlSignals(controlSignals);
					MA_RW_Latch.setRW_enable(true);
					EX_MA_Latch.setMA_enable(false);
				}
			}
		} else System.out.println(" MA Busy");
	}

	@Override
	public void handleEvent(Event e) {
		System.out.println(" MA HE " + instruction.getProgramCounter());

		if(e.getEventType() == EventType.MemoryResponse) {
			MemoryResponseEvent event = (MemoryResponseEvent) e ; 
			MA_RW_Latch.setAluResult(aluResult);
			MA_RW_Latch.setInstruction(instruction);
			MA_RW_Latch.setControlSignals(controlSignals);
			MA_RW_Latch.setLoadResult(event.getValue());
			
			MA_RW_Latch.setRW_enable(true);
			EX_MA_Latch.setMA_enable(false);
			containingProcessor.getLTUnit().set_MABusy(false);
		}
		else if (e.getEventType() == EventType.ExecutionComplete) {
			MA_RW_Latch.setInstruction(instruction);
			MA_RW_Latch.setAluResult(aluResult);
			MA_RW_Latch.setControlSignals(controlSignals);

			MA_RW_Latch.setRW_enable(true);
			EX_MA_Latch.setMA_enable(false);
			containingProcessor.getLTUnit().set_MABusy(false);
		}
	}

}
