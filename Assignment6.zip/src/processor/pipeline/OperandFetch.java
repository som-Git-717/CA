package processor.pipeline;

import processor.Processor;
import generic.Instruction;
import generic.Instruction.OperationType;
import generic.Operand;
import generic.Operand.OperandType;

public class OperandFetch {
	Processor containingProcessor;
	IF_OF_LatchType IF_OF_Latch;
	OF_EX_LatchType OF_EX_Latch;
	IF_EnableLatchType IF_EnableLatch;
	Control_Signals controlSignals;
	
	public OperandFetch(Processor containingProcessor, IF_OF_LatchType iF_OF_Latch, OF_EX_LatchType oF_EX_Latch, IF_EnableLatchType iF_EnableLatch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_OF_Latch = iF_OF_Latch;
		this.OF_EX_Latch = oF_EX_Latch;
		this.IF_EnableLatch = iF_EnableLatch;
	}
	
	private static StringBuilder twosCompliment(StringBuilder input){
		int index=0;
		for (int i = 0; i < input.length(); i++)
		{
			if(input.charAt(i) == '1') index = i;
		}
		StringBuilder output = input;
		for(int i = 0; i < index; i++)
		{
			if (output.charAt(i) == '0') output.setCharAt(i, '1');
			else output.setCharAt(i, '0');
		}
		return output;
	}

	public void performOF()
	{
		System.out.println("Reach OF");
		
		if(IF_OF_Latch.isOF_enable())
		{
			IF_OF_Latch.set_bufferInstruction(true);
			//Control Unit
			controlSignals = new Control_Signals();

			// Instruction Load in Operand
			int newInstruction = IF_OF_Latch.getInstruction();
			String binaryInstruction = Integer.toBinaryString(newInstruction);
			while(binaryInstruction.length()!=32)
			{
				binaryInstruction = "0" + binaryInstruction;
			}

			// Opcode from Instruction
			String opcode = binaryInstruction.substring(0, 5);
			int intOpcode = Integer.parseInt(opcode, 2);

			// Generation of Control Signals for Give instruction
			controlSignals.getControlSignals(intOpcode);
			
			Instruction instruction = new Instruction();
			instruction.setProgramCounter(IF_OF_Latch.get_PerformingPC());

			System.out.println(" OF " + instruction.getProgramCounter());

			// Null operand
			Operand null_operand = new Operand();
			null_operand.setValue(0);

			if (intOpcode % 2 == 0 && intOpcode < 21)
			{
				Operand rs1 = new Operand();
				rs1.setOperandType(OperandType.Register);
				int rs1_RegisterNumber = Integer.parseInt(binaryInstruction.substring(5, 10), 2);
				int rs1_value = containingProcessor.getRegisterFile().getValue(rs1_RegisterNumber);
				rs1.setRegisterNumber(rs1_RegisterNumber);
				rs1.setValue(rs1_value);

				Operand rs2 = new Operand();
				rs2.setOperandType(OperandType.Register);
				int rs2_RegisterNumber = Integer.parseInt(binaryInstruction.substring(10, 15), 2);
				int rs2_value = containingProcessor.getRegisterFile().getValue(rs2_RegisterNumber);
				rs2.setRegisterNumber(rs1_RegisterNumber);
				rs2.setValue(rs2_value);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				int rd_RegisterNumber = Integer.parseInt(binaryInstruction.substring(15, 20), 2);
				rd.setRegisterNumber(rd_RegisterNumber);

				if (containingProcessor.getILUnit().isdataInterlock(rs1_RegisterNumber) || containingProcessor.getILUnit().isdataInterlock(rs2_RegisterNumber))
				{
					IF_OF_Latch.set_stallEnable(true);
					instruction.setSourceOperand1(null_operand);
					instruction.setSourceOperand2(null_operand);
					instruction.setDestinationOperand(null_operand);
					instruction.setProgramCounter(-1);
					controlSignals.getControlSignals(-1);
				}
				else
				{
					instruction.setOperationType(OperationType.values()[intOpcode]);
					instruction.setSourceOperand1(rs1);
					instruction.setSourceOperand2(rs2);
					instruction.setDestinationOperand(rd);
				}

				if (containingProcessor.getILUnit().getIsBranch() == false) containingProcessor.getILUnit().set_dataInterlock(rd_RegisterNumber, 2);

			}
			else if (intOpcode % 2 != 0 && intOpcode <= 21 || intOpcode == 22)
			{
				Operand rs1 = new Operand();
				rs1.setOperandType(OperandType.Register);
				int rs1_RegisterNumber = Integer.parseInt(binaryInstruction.substring(5, 10), 2);
				int rs1_value = containingProcessor.getRegisterFile().getValue(rs1_RegisterNumber);
				rs1.setRegisterNumber(rs1_RegisterNumber);
				rs1.setValue(rs1_value);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				int rd_RegisterNumber = Integer.parseInt(binaryInstruction.substring(10, 15), 2);
				rd.setRegisterNumber(rd_RegisterNumber);

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1' && (Integer.parseInt(immBinary.toString(), 2) != 65536))
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				if (containingProcessor.getILUnit().isdataInterlock(rs1_RegisterNumber))
				{
					IF_OF_Latch.set_stallEnable(true);
					instruction.setSourceOperand1(null_operand);
					instruction.setSourceOperand2(null_operand);
					instruction.setDestinationOperand(null_operand);
					instruction.setProgramCounter(-1);
					controlSignals.getControlSignals(-1);
				}
				else
				{
					instruction.setOperationType(OperationType.values()[intOpcode]);
					instruction.setSourceOperand1(rs1);
					instruction.setSourceOperand2(immediate);
					instruction.setDestinationOperand(rd);
				}

				if (containingProcessor.getILUnit().getIsBranch() == false) containingProcessor.getILUnit().set_dataInterlock(rd_RegisterNumber, 2);
			}
			else if (intOpcode == 23)
			{
				Operand rs1 = new Operand();
				rs1.setOperandType(OperandType.Register);
				int rs1_RegisterNumber = Integer.parseInt(binaryInstruction.substring(5, 10), 2);
				int rs1_value = containingProcessor.getRegisterFile().getValue(rs1_RegisterNumber);
				rs1.setRegisterNumber(rs1_RegisterNumber);
				rs1.setValue(rs1_value);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				int rd_RegisterNumber = Integer.parseInt(binaryInstruction.substring(10, 15), 2);
				int rd_value = containingProcessor.getRegisterFile().getValue(rd_RegisterNumber);
				rd.setRegisterNumber(rd_RegisterNumber);
				rd.setValue(rd_value);

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1' && (Integer.parseInt(immBinary.toString(), 2) != 65536))
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				if (containingProcessor.getILUnit().isdataInterlock(rs1_RegisterNumber) || containingProcessor.getILUnit().isdataInterlock(rd_RegisterNumber))
				{
					IF_OF_Latch.set_stallEnable(true);
					instruction.setSourceOperand1(null_operand);
					instruction.setSourceOperand2(null_operand);
					instruction.setDestinationOperand(null_operand);
					instruction.setProgramCounter(-1);
					controlSignals.getControlSignals(-1);
				}
				else
				{
					instruction.setOperationType(OperationType.values()[intOpcode]);
					instruction.setSourceOperand1(rd);
					instruction.setSourceOperand2(immediate);
					instruction.setDestinationOperand(rs1);
				}

			}
			else if (intOpcode == 24)
			{
				Operand immediate = new Operand();
				
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(10, 32));
				if (immBinary.charAt(0) == '1' && (Integer.parseInt(immBinary.toString(), 2) != 65536))
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(null_operand);
				instruction.setSourceOperand2(immediate);

			}
			else if (intOpcode == 29)
			{
				instruction.setOperationType(OperationType.values()[intOpcode]);
				instruction.setSourceOperand1(null_operand);
				instruction.setSourceOperand2(null_operand);
				instruction.setDestinationOperand(null_operand);

				IF_EnableLatch.setIF_enable(false);
				if (containingProcessor.getILUnit().getIsBranch() == false) containingProcessor.getILUnit().endEnable = 1;
			}
			else
			{
				Operand rs1 = new Operand();
				rs1.setOperandType(OperandType.Register);
				int rs1_RegisterNumber = Integer.parseInt(binaryInstruction.substring(5, 10), 2);
				int rs1_value = containingProcessor.getRegisterFile().getValue(rs1_RegisterNumber);
				rs1.setRegisterNumber(rs1_RegisterNumber);
				rs1.setValue(rs1_value);

				Operand rd = new Operand();
				rd.setOperandType(OperandType.Register);
				int rd_RegisterNumber = Integer.parseInt(binaryInstruction.substring(10, 15), 2);
				int rd_value = containingProcessor.getRegisterFile().getValue(rd_RegisterNumber);
				rd.setRegisterNumber(rd_RegisterNumber);
				rd.setValue(rd_value);

				Operand immediate = new Operand();
				immediate.setOperandType(OperandType.Immediate);
				StringBuilder immBinary = new StringBuilder(binaryInstruction.substring(15, 32));
				if (immBinary.charAt(0) == '1' && (Integer.parseInt(immBinary.toString(), 2) != 65536))
				{
					StringBuilder compliment_immBinary = twosCompliment(immBinary);
					immediate.setValue(Integer.parseInt(compliment_immBinary.toString(), 2)*-1);
				}
				else immediate.setValue(Integer.parseInt(immBinary.toString(), 2));

				if (containingProcessor.getILUnit().isdataInterlock(rs1_RegisterNumber) || containingProcessor.getILUnit().isdataInterlock(rd_RegisterNumber))
				{
					IF_OF_Latch.set_stallEnable(true);
					instruction.setSourceOperand1(null_operand);
					instruction.setSourceOperand2(null_operand);
					instruction.setDestinationOperand(null_operand);
					instruction.setProgramCounter(-1);
					controlSignals.getControlSignals(-1);
				}
				else
				{
					instruction.setOperationType(OperationType.values()[intOpcode]);
					instruction.setSourceOperand1(rs1);
					instruction.setSourceOperand2(immediate);
					instruction.setDestinationOperand(rd);
				}
			}
			
			if (containingProcessor.getLTUnit().is_EXBusy() == false)
			{
				if (instruction.getProgramCounter() != -1) IF_OF_Latch.set_bufferInstruction(false);

				if (containingProcessor.getILUnit().getBT())
				{
					Operand null_Operand = new Operand();
					null_Operand.setValue(0);

					controlSignals = new Control_Signals();
					controlSignals.getControlSignals(-1);

					System.out.println("HEllo OF -1");

					instruction = new Instruction();
					instruction.setProgramCounter(-1);
					instruction.setSourceOperand1(null_Operand);
					instruction.setSourceOperand2(null_Operand);
					instruction.setDestinationOperand(null_Operand);

					containingProcessor.getILUnit().setBT(false);
					containingProcessor.getILUnit().setIsBranch(false);
				}

				OF_EX_Latch.setControlSignals(controlSignals);
				OF_EX_Latch.setInstruction(instruction);
				IF_OF_Latch.setOF_enable(false);
				OF_EX_Latch.setEX_enable(true);
			}
		}
		// else if (containingProcessor.getILUnit().getBT())
		// {

		// 	Operand null_Operand = new Operand();
		// 	null_Operand.setValue(0);

		// 	Control_Signals controlSignals = new Control_Signals();
		// 	controlSignals.getControlSignals(-1);

		// 	System.out.println(" OF -1");

		// 	Instruction instruction = new Instruction();
		// 	instruction.setProgramCounter(-1);
		// 	instruction.setSourceOperand1(null_Operand);
		// 	instruction.setSourceOperand2(null_Operand);
		// 	instruction.setDestinationOperand(null_Operand);

		// 	OF_EX_Latch.setControlSignals(controlSignals);
		// 	OF_EX_Latch.setInstruction(instruction);
		// 	IF_OF_Latch.setOF_enable(false);
		// 	OF_EX_Latch.setEX_enable(true);

		// 	containingProcessor.getILUnit().setBT(false);
		// 	containingProcessor.getILUnit().setIsBranch(false);
		// }
	}

}
