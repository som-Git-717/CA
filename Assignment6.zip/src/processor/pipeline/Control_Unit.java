package processor.pipeline;

public class Control_Unit {
    int opcode;
    boolean isImm = false;
    boolean isStr = false;
    boolean isLd = false;
    boolean isJmp = false;
    int aluSig = 0;

    public void performCU(int opCode)
    {
        this.opcode = opCode;

        if ((opcode%2 == 1 && opcode <= 21) || opcode > 21)
        {
            isImm = true;
        }

        if (opcode == 24)
        {
            isJmp = true;
        }
        else if (opcode == 22)
        {
            isLd = true;
        }
        else if (opcode == 23)
        {
            isStr = true;
        }

        if (opcode == 0 || opcode == 1)
        {
            aluSig = 1; //Addation
        }
        else if(opcode == 2 || opcode == 3)
        {
            aluSig = 2; //Subtraction
        }
        else if(opcode == 4 || opcode == 5)
        {
            aluSig = 3; //Multiplication
        }
        else if (opcode == 6 || opcode == 7)
        {
            aluSig = 4; // Division
        }
        else if (opcode == 8 || opcode == 9)
        {
            aluSig = 5; // And
        }
        else if (opcode == 10 || opcode == 11)
        {
            aluSig = 6; // Or
        }
        else if (opcode == 12 || opcode == 13)
        {
            aluSig = 7; // Xor
        }
        else if (opcode == 14 || opcode == 15)
        {
            aluSig = 8; // Strictly less than condition
        }
        else if (opcode == 16 || opcode == 17)
        {
            aluSig = 9; // Logical left shift
        }
        else if (opcode == 18 || opcode == 19)
        {
            aluSig = 10; // logical right shit
        }
        else if (opcode == 20 || opcode == 21)
        {
            aluSig = 11; // arithmetic right
        }
        else if (opcode == 25) aluSig = 12; // Branch Equivalent
        else if (opcode == 26) aluSig = 13; // Branch not equivalent
        else if (opcode == 27) aluSig = 14; // Branch less than condition
        else if (opcode == 28) aluSig = 15; // Branch greater than condition
    }
}
