package processor.pipeline;

public class Latency_Unit {
    boolean IFBusy;
    boolean OFBusy;
    boolean EXBusy;
    boolean MABusy;

    public Latency_Unit(){
        IFBusy = false;
        OFBusy = false;
        EXBusy = false;
        MABusy = false;
    }

    public boolean is_IFBusy(){
        return IFBusy;
    }

    public void set_IFBusy(boolean value){
        IFBusy = value;
    }

    public boolean is_OFBusy(){
        return OFBusy;
    }

    public void set_OFBusy(boolean value){
        OFBusy = value;
    }

    public boolean is_EXBusy(){
        return EXBusy;
    }

    public void set_EXBusy(boolean value){
        EXBusy = value;
    }

    public boolean is_MABusy(){
        return MABusy;
    }

    public void set_MABusy(boolean value){
        MABusy = value;
    }
    
}
