package processor.pipeline;

public class Control_Signals {
    boolean isImm = false;
    boolean isStr = false;
    boolean isLd = false;
    boolean isJmp = false;
    int aluSignal;

    public boolean isImmediate()
    {
        return isImm;
    }

    public boolean isStore()
    {
        return isStr;
    }

    public boolean isLoad()
    {
        return isLd;
    }

    public boolean isJump()
    {
        return isJmp;
    }

    public int getAluSignal()
    {
        return aluSignal;
    }

    public void getControlSignals(int opcode)
    {
        Control_Unit control_unit = new Control_Unit();
        control_unit.performCU(opcode);
        isImm = control_unit.isImm;
        isJmp = control_unit.isJmp;
        isLd = control_unit.isLd;
        isStr = control_unit.isStr;
        aluSignal = control_unit.aluSig; 

    }
}
