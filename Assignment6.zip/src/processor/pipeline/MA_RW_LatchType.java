package processor.pipeline;

import generic.Instruction;

public class MA_RW_LatchType {
	
	boolean RW_enable;
	int loadResult;
	int aluResult;
	Instruction instruction;
	Control_Signals controlSignals;
	int insPC;
	boolean isnop;
	boolean isLd;
	boolean MABusy;
	
	public MA_RW_LatchType()
	{
		RW_enable = false;
		isLd=false;
		isnop=false;
		insPC=-1;
		MABusy = false;
	}

	public boolean isRW_enable() {
		return RW_enable;
	}

	public void setRW_enable(boolean rW_enable) {
		RW_enable = rW_enable;
	}

	public int getAluResult()
	{
		return aluResult;
	}

	public void setAluResult(int result)
	{
		this.aluResult = result;
	}

	public int getLoadResult()
	{
		return loadResult;
	}

	public void setLoadResult(int result)
	{
		this.loadResult = result;
	}

	public Instruction getInstruction()
	{
		return instruction;
	}

	public void setInstruction(Instruction instruction)
	{
		this.instruction = instruction;
	}

	public Control_Signals geControlSignals()
	{
		return controlSignals;
	}

	public void setControlSignals(Control_Signals controlSignals)
	{
		this.controlSignals = controlSignals;
	}

	public void setMABusy (boolean value){
		MABusy = value;
	}

	public boolean isMABusy(){
		return MABusy;
	}

}
