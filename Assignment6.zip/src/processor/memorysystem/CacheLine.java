package processor.memorysystem;

public class CacheLine {

    int tag;
    int data;

    public CacheLine(){
        tag = -1;
        data = Integer.MIN_VALUE;
    }

    public void setTag(int tag){
        this.tag = tag;
    }

    public int getTag(){
        return tag;
    }

    public void setData(int data){
        this.data = data;
    }

    public int getData(){
        return data;
    }
}