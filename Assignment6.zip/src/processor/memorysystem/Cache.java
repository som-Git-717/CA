package processor.memorysystem;

import generic.Element;
import generic.MemoryReadEvent;
import generic.MemoryResponseEvent;
import generic.MemoryWriteEvent;
import processor.Clock;
import generic.Simulator;
import processor.Processor;
import generic.Event;
import generic.ExecutionCompleteEvent;
import configuration.Configuration;
import java.util.LinkedList;
import java.util.Queue;

public class Cache implements Element{
    Processor containingProcessor;

    int lineSize; // In Bytes
    int cacheSize; // In Bytes
    int noOfLines;
    int cacheLatency;
    Queue<Integer> cacheQueue;

    boolean isCacheMiss;
    boolean isWrite;

    int dataToReplace;

    Element stageUnit;

    CacheLine[] cacheUnit;

    public Cache(int size, Processor containingProcessor, Element stageUnit) {
        this.containingProcessor = containingProcessor;

        isCacheMiss = false;
        isWrite = false;

        dataToReplace = Integer.MIN_VALUE;

        lineSize = 4;
        cacheSize = size;

        this.stageUnit = stageUnit;

        noOfLines = cacheSize / lineSize;

        switch (cacheSize) {
            case 16:
                cacheLatency = 1;
                break;
            case 128:
                cacheLatency = 2;
                break;
            case 512:
                cacheLatency = 3;
                break;
            case 1024:
                cacheLatency = 4;
                break;
        
            default:
                break;
        }

        cacheUnit = new CacheLine[noOfLines];
        cacheQueue = new LinkedList<>();

        for (int i = 0; i < noOfLines; i++){
            cacheUnit[i] = new CacheLine();
            cacheQueue.offer(-1);
        }
    }

    public void handleCacheMiss(int address){
        int cacheMissAddress = address;
        Simulator.getEventQueue().addEvent(new MemoryReadEvent(Clock.getCurrentTime() + Configuration.mainMemoryLatency, this, containingProcessor.getMainMemory(), cacheMissAddress));
    }

    public void handleResponse(int data, int address){
        int tag = cacheQueue.peek();

        cacheQueue.poll();
        cacheQueue.offer(address);
        
        if (isWrite == false)
        {
            if (tag == -1){
                for (int i = 0; i < noOfLines; i++){
                    if (cacheUnit[i].getTag() == -1){
                        cacheUnit[i].setTag(address);
                        cacheUnit[i].setData(data);
                    }
                }
            }
            else{
                for (int i = 0; i < noOfLines; i++){
                    if (cacheUnit[i].getTag() == tag){
                        cacheUnit[i].setTag(address);
                        cacheUnit[i].setData(data);
                    }
                }
            }

            Simulator.getEventQueue().addEvent(new MemoryResponseEvent(Clock.getCurrentTime(), this, stageUnit, data, address));
        }
        else
        {
            containingProcessor.getMainMemory().setWord(address, dataToReplace);

            if (tag == -1){
                for (int i = 0; i < noOfLines; i++){
                    if (cacheUnit[i].getTag() == -1){
                        cacheUnit[i].setTag(address);
                        cacheUnit[i].setData(dataToReplace);
                    }
                }
            }
            else{
                for (int i = 0; i < noOfLines; i++){
                    if (cacheUnit[i].getTag() == tag){
                        cacheUnit[i].setTag(address);
                        cacheUnit[i].setData(dataToReplace);
                    }
                }
            }

            Simulator.getEventQueue().addEvent(new ExecutionCompleteEvent(Clock.getCurrentTime(), this, stageUnit));
        }
    }

    public void cacheRead(int address, Element requestingElement){
        int cacheAddress = address;
        
        System.out.println("Cache Read: " + address);
        for (int i = 0; i < noOfLines; i++)
        {
            isCacheMiss = true;
            if (cacheUnit[i].getTag() == cacheAddress)
            {
                isCacheMiss = false;

                Simulator.getEventQueue().addEvent(
                    new MemoryResponseEvent( 
					Clock.getCurrentTime(), 
					this, 
					requestingElement, 
					cacheUnit[i].getData(),
					cacheAddress)
                );
            }
        }

        if (isCacheMiss){
            handleCacheMiss(cacheAddress);
        }
    }

    public void cacheWrite(int address, int data, Element requestingElement){
        int cacheAddress = address;

        for (int i = 0; i < noOfLines; i++)
        {
            isCacheMiss = true;
            if (cacheUnit[i].getTag() == cacheAddress)
            {
                isCacheMiss = false;

                containingProcessor.getMainMemory().setWord(cacheAddress, data);

                cacheUnit[i].setData(data);

                Simulator.getEventQueue().addEvent(
                    new ExecutionCompleteEvent( 
					Clock.getCurrentTime(), 
					this, 
					requestingElement)
                );
            }
        }

        if (isCacheMiss){
            handleCacheMiss(cacheAddress);
            dataToReplace = data;
        }
    }

    public int getcacheLatency(){
        return cacheLatency;
    }

    @Override

	public void handleEvent(Event e) {
        if (e.getEventType() == Event.EventType.MemoryRead) {
			MemoryReadEvent event = (MemoryReadEvent) e ; 

			cacheRead(event.getAddressToReadFrom(), event.getRequestingElement());
            isWrite = false;
		}
        else if (e.getEventType() == Event.EventType.MemoryResponse){
            MemoryResponseEvent event = (MemoryResponseEvent) e;

            handleResponse(event.getValue(), event.getPCValue());
        }
        else if (e.getEventType() == Event.EventType.MemoryWrite){
            MemoryWriteEvent event = (MemoryWriteEvent) e;
            cacheWrite(event.getAddressToWriteTo(), event.getValue(), event.getRequestingElement());
            isWrite = true;
        }
	}
}
