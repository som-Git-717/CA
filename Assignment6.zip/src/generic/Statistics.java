package generic;

import java.io.PrintWriter;

public class Statistics {
	
	// TODO add your statistics here
	static int numberOfInstructions;
	static int numberOfCycles;
	static int numberOfStalls;
	static int numberOfBranch;
	static float CPI;
	static float IPC;
	

	public static void printStatistics(String statFile)
	{
		try
		{
			PrintWriter writer = new PrintWriter(statFile);
			
			writer.println("Number of dynamic instructions executed = " + numberOfInstructions);
			writer.println("Number of total instruction executed (including bubbles) = " + ( numberOfInstructions + numberOfBranch + numberOfStalls));
			writer.println("Number of cycles taken = " + numberOfCycles);
			writer.println("Number of OF stage stall = " + numberOfStalls);
			writer.println("Number of Wrong Branch Taken = " + numberOfBranch);
			// int instructionsExecuted = numberOfInstructions - numberOfStalls - 2 * numberOfBranch;
			CPI = (float) numberOfCycles / (float) numberOfInstructions;
			writer.println("CPI= " + CPI);
			IPC=(float)1/(float)CPI;
			writer.println("IPC = " + IPC);
			// TODO add code here to print statistics in the output file
			
			writer.close();
		}
		catch(Exception e)
		{
			Misc.printErrorAndExit(e.getMessage());
		}
	}
	
	// TODO write functions to update statistics
	public static void setNumberOfInstructions(int numberOfInstructions) {
		Statistics.numberOfInstructions = numberOfInstructions;
	}

	public static int getNumberOfInstructions(){
		return Statistics.numberOfInstructions;
	}

	public static void setNumberOfCycles(int numberOfCycles) {
		Statistics.numberOfCycles = numberOfCycles;
	}

	public static int getNumberOfCycles(){
		return Statistics.numberOfCycles;
	}

	// public static float getCPI(int numberOfCycles,int numberOfInstructions,int numberOfStalls,int numberOfBranch){
	// 	int instructionsExecuted = numberOfInstructions - numberOfStalls - 2 * numberOfBranch;
	// 	CPI = (float) numberOfCycles / (float) instructionsExecuted;
    //     return CPI;
	// }

	// public static float getIPC(){
	// 	Statistics.IPC= (float)1/(float)CPI;
	// 	return IPC;
	// }
}
