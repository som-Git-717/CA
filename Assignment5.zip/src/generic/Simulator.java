package generic;

import java.io.DataInputStream;
import java.io.FileInputStream;
// import java.io.FileNotFoundException;
import java.io.IOException;
// import java.io.InputStream;
import java.util.Arrays;

import processor.Clock;
import processor.Processor;

public class Simulator {
		
	static Processor processor;
	static boolean simulationComplete;
	static EventQueue eventQueue;
	
	public static void setupSimulation(String assemblyProgramFile, Processor p)
	{	
		eventQueue = new EventQueue();
		Simulator.processor = p;
		loadProgram(assemblyProgramFile);
		
		simulationComplete = false;
	}
	
	static void loadProgram(String assemblyProgramFile)
	{
		try (DataInputStream dataInputStream = new DataInputStream(new FileInputStream(assemblyProgramFile))) {
			int PC = dataInputStream.readInt();
			processor.getRegisterFile().setProgramCounter(PC);
			int address = 0;
            while (dataInputStream.available() >= 4) {
				int instruction = dataInputStream.readInt();
				processor.getMainMemory().setWord(address, instruction);
				address++;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

		processor.getRegisterFile().setValue(1, 65535);
		processor.getRegisterFile().setValue(2, 65535);
		// processor.printState(0, 20);
	}

	public static EventQueue getEventQueue(){
		return eventQueue;
	}
	
	public static void simulate()
	{
		while(simulationComplete == false)
		{
			System.out.println("-----------------------------");
			System.out.println(Clock.getCurrentTime());
			System.out.println(Arrays.toString(processor.getILUnit().printArray()));
			System.out.println("Number of Events: " + eventQueue.getSize());

			processor.getRWUnit().performRW();
			processor.getMAUnit().performMA();
			processor.getEXUnit().performEX();
			eventQueue.processEvents();
			processor.getOFUnit().performOF();
			processor.getIFUnit().performIF();
			Clock.incrementClock();

			processor.getRegisterFile().setValue(0, 0);
			// if (Clock.getCurrentTime() >= 250) setSimulationComplete(true);
			
			Statistics.setNumberOfCycles(Statistics.getNumberOfCycles() + 1);
			// Statistics.getCPI();
			// Statistics.getIPC();
		}

		if (simulationComplete == true)
		{
			Statistics.numberOfStalls = processor.getILUnit().getNoDataHazard();
			Statistics.numberOfBranch = processor.getILUnit().getNoControlHazard();
			
		}
		
		// TODO
		// set statistics
	}
	
	public static void setSimulationComplete(boolean value)
	{
		simulationComplete = value;
	}
}
