package generic;

import processor.pipeline.Control_Signals;
import processor.pipeline.EX_IF_LatchType;;

public class ALUResponseEvent extends Event{

    public int aluResult;
    public Instruction instruction;
    public Control_Signals controlSignals;
    public EX_IF_LatchType EX_IF_Latch;

    public ALUResponseEvent(long eventTime, Element requestingElement, Element processingElement, int aluResult, Instruction instruction, Control_Signals controlSignals, EX_IF_LatchType EX_IF_Latch)
	{
		super(eventTime, EventType.ExecutionComplete, requestingElement, processingElement);
        this.aluResult = aluResult;
        this.instruction = instruction;
        this.controlSignals = controlSignals;
        this.EX_IF_Latch = EX_IF_Latch;
	}
}
