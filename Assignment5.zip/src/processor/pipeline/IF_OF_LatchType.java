package processor.pipeline;

public class IF_OF_LatchType {
	
	boolean OF_enable;
	int instruction;
	int PerfomingPC;
	boolean Stall_enable;
	boolean buffer_Instruction;
	
	public IF_OF_LatchType()
	{
		OF_enable = false;
		Stall_enable = false;
		buffer_Instruction = false;
	}

	public boolean isOF_enable() {
		return OF_enable;
	}

	public void setOF_enable(boolean oF_enable) {
		OF_enable = oF_enable;
	}

	public int getInstruction() {
		return instruction;
	}

	public void setInstruction(int instruction) {
		this.instruction = instruction;
	}

	public void set_PerformingPC(int PC){
		PerfomingPC = PC;
	}

	public int get_PerformingPC(){
		return PerfomingPC;
	}

	public void set_stallEnable(boolean stall_enable){
		Stall_enable = stall_enable;
	}

	public boolean get_stallEnable(){
		return Stall_enable;
	}

	public void set_bufferInstruction(boolean value){
		buffer_Instruction = value;
	}

	public boolean is_bufferInstruction() {
		return buffer_Instruction;
	}

}
