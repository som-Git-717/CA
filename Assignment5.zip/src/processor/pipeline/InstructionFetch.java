package processor.pipeline;

import processor.Processor;
import generic.*;
import processor.Clock;
import configuration.Configuration;

public class InstructionFetch implements Element{
	
	Processor containingProcessor;
	IF_EnableLatchType IF_EnableLatch;
	IF_OF_LatchType IF_OF_Latch;
	EX_IF_LatchType EX_IF_Latch;
	int currentPC;
	
	public InstructionFetch(Processor containingProcessor, IF_EnableLatchType iF_EnableLatch, IF_OF_LatchType iF_OF_Latch, EX_IF_LatchType eX_IF_Latch)
	{
		this.containingProcessor = containingProcessor;
		this.IF_EnableLatch = iF_EnableLatch;
		this.IF_OF_Latch = iF_OF_Latch;
		this.EX_IF_Latch = eX_IF_Latch;
	}
	
	public void performIF()
	{
		System.out.println("Reach IF");
		if (containingProcessor.getLTUnit().is_IFBusy() == false)
		{
			if(IF_EnableLatch.isIF_enable())
			{
				currentPC = 0;

				if (EX_IF_Latch.isIFE_enable())
				{
					currentPC = EX_IF_Latch.getbranchPC();
				}
				else
				{
					currentPC = containingProcessor.getRegisterFile().getProgramCounter();
					
				}

				Simulator.getEventQueue().addEvent(new MemoryReadEvent(Clock.getCurrentTime()+Configuration.mainMemoryLatency, this, containingProcessor.getMainMemory(), currentPC));
				containingProcessor.getLTUnit().set_IFBusy(true);
				System.out.println(" IF Accessing");				
			}
		}
		else System.out.println(" IF Busy"); 

		if (IF_OF_Latch.is_bufferInstruction() == true){
			IF_OF_Latch.setOF_enable(true);
		}
		
	}

	@Override

	public void handleEvent(Event e) {
		if(IF_OF_Latch.get_stallEnable()) 
		{
			e.setEventTime(Clock.getCurrentTime() + 1);
			Simulator.getEventQueue().addEvent(e);

			containingProcessor.getILUnit().number_DataHarzard += 1;
			IF_OF_Latch.set_stallEnable(false);

		}
		else 
		{
			MemoryResponseEvent event = (MemoryResponseEvent) e ;
			IF_OF_Latch.setInstruction(event.getValue());
			IF_OF_Latch.set_PerformingPC(event.getPCValue());
			containingProcessor.getRegisterFile().setProgramCounter(currentPC + 1);

			System.out.println(" IF " + event.getPCValue());

			IF_OF_Latch.setOF_enable(true);
			containingProcessor.getLTUnit().set_IFBusy(false);
			if (EX_IF_Latch.getbranchPC() == currentPC) EX_IF_Latch.setIFE_enable(false);

			Statistics.setNumberOfInstructions(Statistics.getNumberOfInstructions() + 1);
		}
	}

}