package generic;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.io.BufferedOutputStream;
import generic.Operand.OperandType;


public class Simulator {
		
	static FileInputStream inputcodeStream = null;

	private static StringBuilder twosCompliment(StringBuilder input){
		int index=0;
		for (int i = 0; i < input.length(); i++)
		{
			if(input.charAt(i) == '1') index = i;
		}
		StringBuilder output = input;
		for(int i = 0; i < index; i++)
		{
			if (output.charAt(i) == '0') output.setCharAt(i, '1');
			else output.setCharAt(i, '0');
		}
		return output;
	}

	private static StringBuilder padZeros(String input, int length) {
        StringBuilder result = new StringBuilder(input);
        while (result.length() < length) {
            result.insert(0, '0');
        }
        return result;
    }

	private static byte[] convertBinaryStringToByteArray(String binaryString) {
        int len = binaryString.length();
        byte[] byteArray = new byte[len / 8];
        
        for (int i = 0; i < len; i += 8) {
            String byteString = binaryString.substring(i, Math.min(i + 8, len));
            byte b = (byte) Integer.parseInt(byteString, 2);
            byteArray[i / 8] = b;
        }
        
        return byteArray;
    }

	public static void setupSimulation(String assemblyProgramFile)
	{	
		int firstCodeAddress = ParsedProgram.parseDataSection(assemblyProgramFile);
		ParsedProgram.parseCodeSection(assemblyProgramFile, firstCodeAddress);
		ParsedProgram.printState();
	}
	
	public static void assemble(String objectProgramFile)
	{
		try(FileOutputStream outputStream = new FileOutputStream(objectProgramFile))
		{
			BufferedOutputStream binaryOutputStream = new BufferedOutputStream(outputStream);
			byte[] byte_firstAddressCode = ByteBuffer.allocate(4).putInt(ParsedProgram.firstCodeAddress).array();
			binaryOutputStream.write(byte_firstAddressCode);

			for (int data : ParsedProgram.data){
				byte[] byte_data = ByteBuffer.allocate(4).putInt(data).array();
				binaryOutputStream.write(byte_data);
			}

			for (Instruction instruct : ParsedProgram.code){
				int opcode = instruct.getOperationType().ordinal();

				if (opcode % 2 == 0 && opcode < 21){
					StringBuilder assemble_instruct = padZeros(Integer.toBinaryString(opcode), 5);
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand1().getValue()), 5));
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand2().getValue()), 5));
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getDestinationOperand().getValue()), 5));
					assemble_instruct.append("0".repeat(12));
					String assemble = assemble_instruct.toString();
					byte[] byteAssemble = convertBinaryStringToByteArray(assemble);
					binaryOutputStream.write(byteAssemble);
				}
				else if (opcode % 2 != 0 && opcode <= 21 || opcode == 22 || opcode ==23){
					StringBuilder assemble_instruct = padZeros(Integer.toBinaryString(opcode), 5);
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand1().getValue()), 5));
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getDestinationOperand().getValue()), 5));
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand2().getValue()), 17));
					String assemble = assemble_instruct.toString();
					byte[] byteAssemble = convertBinaryStringToByteArray(assemble);
					binaryOutputStream.write(byteAssemble);
				}
				else if (opcode == 24)
				{
					StringBuilder assemble_instruct = padZeros(Integer.toBinaryString(opcode), 5);
					assemble_instruct.append("0".repeat(5));
					String label = instruct.getDestinationOperand().getLabelValue();
					int label_value = ParsedProgram.symtab.get(label);
					int pc = instruct.getProgramCounter();

					if (label_value - pc < 0){
						assemble_instruct.append(twosCompliment(padZeros(Integer.toBinaryString(pc - label_value), 22)));
					}
					else{
						assemble_instruct.append(padZeros(Integer.toBinaryString(label_value - pc), 22));
					}
					String assemble = assemble_instruct.toString();
					byte[] byteAssemble = convertBinaryStringToByteArray(assemble);
					binaryOutputStream.write(byteAssemble);

				}
				else if (opcode == 29){
					StringBuilder assemble_instruct = padZeros(Integer.toBinaryString(opcode), 5);
					assemble_instruct.append("0".repeat(27));
					String assemble = assemble_instruct.toString();
					byte[] byteAssemble = convertBinaryStringToByteArray(assemble);
					binaryOutputStream.write(byteAssemble);
				}
				else{
					StringBuilder assemble_instruct = padZeros(Integer.toBinaryString(opcode), 5);
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand1().getValue()), 5));
					assemble_instruct.append(padZeros(Integer.toBinaryString(instruct.getSourceOperand2().getValue()), 5));
					String label = instruct.getDestinationOperand().getLabelValue();
					int label_value = ParsedProgram.symtab.get(label);
					int pc = instruct.getProgramCounter();
					if (label_value - pc < 0){
						assemble_instruct.append(twosCompliment(padZeros(Integer.toBinaryString(pc - label_value), 17)));
					}
					else{
						assemble_instruct.append(padZeros(Integer.toBinaryString(label_value - pc), 17));
					}
					String assemble = assemble_instruct.toString();
					byte[] byteAssemble = convertBinaryStringToByteArray(assemble);
					binaryOutputStream.write(byteAssemble);
				}
			}

			binaryOutputStream.flush();
			binaryOutputStream.close();

		} catch (FileNotFoundException e) {
			System.out.println("File not Found: " + objectProgramFile);
		} catch (IOException e){
			System.out.println("IOException: " + e.getMessage());
		}
	}
	
}
